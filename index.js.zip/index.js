exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Hello from John v3.0');
};
